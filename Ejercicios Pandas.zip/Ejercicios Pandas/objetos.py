import pandas as pd

pd.__version__

class Usuario:
    def __init__(self,nombre,password):
        self.nombre=nombre
        self.password=password
        print('nom:'+self.nombre+', pas:'+self.password)

    
        