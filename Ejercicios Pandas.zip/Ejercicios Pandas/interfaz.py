from metodo import inicioSesion
from tkinter import *
import tkinter as tk
from tkinter import ttk

if __name__=="__main__":
    root=tk.Tk()
    inicioSesion=inicioSesion(root)
    root.mainloop()