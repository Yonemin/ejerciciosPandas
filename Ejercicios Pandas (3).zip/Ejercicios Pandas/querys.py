from tkinter import *
import tkinter as tk
from tkinter import messagebox, Frame, Button
import pandas as pd
from pandastable import Table
import csv
pd.__version__

df_archivo_2=pd.read_csv("Sacramentorealestatetransactions.csv")

class Menu(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master,width=1200,height=1200)
        self.master = master
        self.pack()
        self.botones()

    def botones(self):
        self.espacio_label=tk.Label(self,background='lightblue',text=" ")
        self.espacio_label.pack()

        self.uno_button=tk.Button(self,text="Viviendas en Sacramento, excepto las que tengan solo un baño y una habitación.",font=(20),command=self.query_1)
        self.uno_button.pack()

        self.dos_button=tk.Button(self,text="Viviendas en Rancho Cordova y Antelope que cuesten menos de 150 000",font=(20),command=self.query_2)
        self.dos_button.pack()

        self.tres_button=tk.Button(self,text="Viviendas que no tienen ni habitaciones ni baños",font=(20),command=self.query_3)
        self.tres_button.pack()

        self.cua_button=tk.Button(self,text="Residencias en una latitud menor a 38.5 en Sloughhouse",font=(20),command=self.query_4)
        self.cua_button.pack()

        self.cin_button=tk.Button(self,text="Viviendas vendidas el 19 de Mayo",font=(20),command=self.query_5)
        self.cin_button.pack()

        self.seis_button=tk.Button(self,text="",font=(20),command=self.query_6)
        self.seis_button.pack()

        self.sie_button=tk.Button(self,text="",font=(20),command=self.query_7)
        self.sie_button.pack()

        self.ocho_button=tk.Button(self,text="",font=(20),command=self.query_8)
        self.ocho_button.pack()

        self.nue_button=tk.Button(self,text="",font=(20),command=self.query_9)
        self.nue_button.pack()

        self.diez_button=tk.Button(self,text="",font=(20),command=self.query_10)
        self.diez_button.pack()

        self.quit = tk.Button(self, text="Salir", fg="red", font=(20), command=self.master.destroy)
        self.quit.pack(side="bottom")

    def query_1(self):
        city="SACRAMENTO"
        beds=3
        baths=1
        result = df_archivo_2.query("city==@city and beds!=@beds and baths!=@baths")
        print('1:')
        print(result)
        #self.table = pt = Table(root, dataframe=result)
        #pt.show()

    def query_2(self):
        city1="RANCHO CORDOVA"
        city2="ANTELOPE"
        price=150000
        result = df_archivo_2.query("city==@city1 and price<@price or city==@city2 and price<@price")
        print('2:')
        print(result)

    def query_3(self):
        beds=0
        baths=0
        result = df_archivo_2.query("beds==@beds and baths==@baths")
        print('3:')
        print(result)

    def query_4(self):
        city="SLOUGHHOUSE"
        latitude = 38.5
        result = df_archivo_2.query("city==@city and latitude<@latitude")
        print('4:')
        print(result)

    def query_5(self):
        #Mon May 19 00:00:00 EDT 2008
        sale_date = 'Mon May 19 00:00:00 EDT 2008'
        result = df_archivo_2.query("sale_date==@sale_date")
        print('5:')
        print(result)

    def query_6(self):
        city="SACRAMENTO"
        beds=3
        baths=1
        result = df_archivo_2.query("city==@city and beds!=@beds and baths!=@baths")
        print('6:')
        print(result)

    def query_7(self):
        city="SACRAMENTO"
        beds=3
        baths=1
        result = df_archivo_2.query("city==@city and beds!=@beds and baths!=@baths")
        print('7:')
        print(result)

    def query_8(self):
        city="SACRAMENTO"
        beds=3
        baths=1
        result = df_archivo_2.query("city==@city and beds!=@beds and baths!=@baths")
        print('8:')
        print(result)

    def query_9(self):
        city="SACRAMENTO"
        beds=3
        baths=1
        result = df_archivo_2.query("city==@city and beds!=@beds and baths!=@baths")
        print('9:')
        print(result)

    def query_10(self):
        city="SACRAMENTO"
        beds=3
        baths=1
        result = df_archivo_2.query("city==@city and beds!=@beds and baths!=@baths")
        print('10:')
        print(result)

if __name__=="__main__":
        root = tk.Tk()
        app = Menu(root)
        #app.wm_title('Menú')
        app.mainloop()
